# 📰 Diario Escolar - Escuela 32 Caudillos Riojanos

📍 Paraje Cebollar, La Rioja – Argentina  
👨‍🏫 Director: Prof. Humberto Cáceres  
📅 Año 2025  

Este es el **Diario Escolar virtual estilo revista** de la **Escuela 32 Caudillos Riojanos**.  
Incluye una versión web y un archivo PDF descargable.

---

## 🚀 Funcionalidades

✅ Portada estilo revista con fotos y textos.  
✅ Galería de actividades de los alumnos.  
✅ Botón para **descargar el PDF**.  
✅ Listo para publicar en **GitHub Pages**.  

---

## 📂 Archivos incluidos

- `index.html` → Página principal del diario  
- `style.css` → Estilos modernos estilo revista  
- `Diario_Escolar_Escuela32.pdf` → Versión descargable en PDF  
- `img/` → Carpeta con imágenes usadas en el diario  

---

## 🌐 Publicar en GitHub Pages

1. Crear un repositorio en GitHub (ej: `diario-escuela32`).  
2. Subir todos los archivos del proyecto.  
3. Ir a **Settings > Pages**.  
4. En **Branch**, seleccionar `main` y carpeta `/root`.  
5. Guardar cambios.  
6. Tu sitio estará disponible en:  

👉 `https://tuusuario.github.io/diario-escuela32/`

---

✍️ Desarrollado para la **Escuela 32 Caudillos Riojanos**  
👨‍🏫 Prof. Humberto Cáceres – © 2025
